import datetime
import sqlite3 as sql
import time
import warnings

import docx2txt
from application.models import Jobs, Sample
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage
from django.shortcuts import redirect, render
from pyresparser import ResumeParser

warnings.filterwarnings('ignore')
import pdfplumber
import sklearn
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Create your views here.

def home(request):
    return render(request,"home.html")

def index(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username,password = password)
        if user is not None:
            login(request,user)
            return redirect('/dashboard')
        else:
            return render(request,'index.html')
    return render(request,"index.html")
def logoutUser(request):
    logout(request)
    return redirect("/index")
@login_required(login_url='index/')

def applicants(request):
    appl = Sample.objects.all()
    print(appl)
    return render(request,"applicants.html",{'appl':appl})
@login_required(login_url='index/')
def dashboard(request):
    if request.user.is_anonymous:
        return redirect("/index")
    return render(request,"dashboard.html")


@login_required(login_url='index/')
def job(request):
    job = Jobs.objects.all()
    return render(request,"jobslist.html",{'job':job})
@login_required(login_url='index/')
def job_form(request):
    if request.method =="POST":
        if 'Save' in request.POST:

            job_title =  request.POST.get('job_title')
            team = request.POST.get('team')
            industry = request.POST.get('industry')
            country = request.POST.get('country')
            remote_job = request.POST.get('remote_job')
            employment_team = request.POST.get('employment_team')
            employment_type = request.POST.get('employment_type')
            experience = request.POST.get('experience')
            pay_rate = request.POST.get('pay_rate')
            job_description = request.POST.get('job_description')
            print('job_title'+job_title)
            jobs = Jobs(job_title=job_title,team=team,industry=industry,country=country,remote_job=remote_job,employment_team=employment_team,employment_type=employment_type,experience=experience,pay_rate=pay_rate,job_description=job_description)
            jobs.save()
            return redirect('job/')
    return render(request,"job_form.html")   
        
        
@login_required(login_url='index/')
def upload(request):
    a = Jobs.objects.all()
    context={}
    if request.method == "POST":
        uploaded_file = request.FILES['document']
        fs = FileSystemStorage()
        f = fs.save(uploaded_file.name, uploaded_file)
        context['url'] = fs.url(f)
        f1 = fs.path(uploaded_file.name)
        print(uploaded_file.name)
        resume_text = ResumeParser(f1).get_extracted_data()
        print(resume_text)
        name = resume_text['name']
        email =  resume_text['email']
        contact =  resume_text['mobile_number']
        skills = str(resume_text['skills'])
        resume_pages = str(resume_text['no_of_pages'])
        
        ts = time.time()
        cur_date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%D')
        cur_time = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
        Timestamp = str(cur_date + '_' + cur_time)
        
        import pdfplumber
        with pdfplumber.open(uploaded_file.name) as pdf:
            resume = pdf.pages[0]
            print(resume.extract_text())
            
        job = docx2txt.process('python-job-description.docx')

        text = [resume.extract_text(),job]

        cv = CountVectorizer()
        count_matrix = cv.fit_transform(text)

        #print similarity score
        #print(resume)
        print('Similarity score : ',cosine_similarity(count_matrix))

        matchpercentage = cosine_similarity(count_matrix)[0][1]
        matchpercentage = round(matchpercentage*100,2)
        print('Your Resume {} % match to the job description !'.format(matchpercentage))
        sample = Sample(name=name,email=email,contact=contact,skills=skills,resume_pages=resume_pages,resume_score=matchpercentage)
        sample.save()
        
        
        
    return render(request,"upload.html", context)