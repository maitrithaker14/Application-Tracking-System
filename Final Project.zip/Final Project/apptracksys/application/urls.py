from . import views
from django.urls import path


urlpatterns = [
    path("",views.home,name="index"),
    path("applicants/",views.applicants,name="applicants"),
    path("dashboard",views.dashboard,name="dashboard"),
    path("index/",views.index,name="index"),
    path("job/",views.job,name="job"),
    path("job_form",views.job_form,name="job_form"),
    path("upload",views.upload,name="upload"),
    path("logout/",views.logoutUser,name="logout"),

]

