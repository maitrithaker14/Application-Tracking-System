from django.db import models

# Create your models here.

class Sample(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=254)
    contact = models.IntegerField(null=True)
    skills = models.CharField(max_length=254)
    resume_pages = models.CharField(max_length=254)
    resume_score = models.CharField(max_length=254)
    timestamp = models.DateTimeField(auto_now_add=True)

    # def __str__(self) -> str:
    #     return self.name

'''class Jobs(models.Model):
    id = models.AutoField(primary_key=True)
    job_title = models.CharField(max_length=255,null=False)
    team = models.CharField(max_length=255)
    industry = models.CharField(max_length=255)
    country = models.CharField(max_length=255)
    remote_job = models.CharField(max_length=255)
    employment_team = models.CharField(max_length=255)
    employment_type = models.CharField(max_length=255)
    experience = models.CharField(max_length=255)
    pay_rate = models.CharField(max_length=255,null=True,blank=True)
    job_description = models.TextField(null=True,blank=True)

    class Meta:
        verbose_name = 'Job'
        verbose_name_plural = 'Jobs '''
    # def __str__(self):
    #     return self.job_title
class Jobs(models.Model):
    id = models.AutoField(primary_key=True)
    job_title = models.CharField(max_length=255,null=True,blank=True)
    team = models.CharField(max_length=255,null=True,blank=True)
    industry = models.CharField(max_length=255,null=True,blank=True)
    country = models.CharField(max_length=255,null=True,blank=True)
    remote_job = models.CharField(max_length=255,null=True,blank=True)
    employment_team = models.CharField(max_length=255,null=True,blank=True)
    employment_type = models.CharField(max_length=255,null=True,blank=True)
    experience = models.CharField(max_length=255,null=True,blank=True)
    pay_rate = models.CharField(max_length=255,null=True,blank=True)
    job_description = models.TextField(null=True,blank=True)

    def __str__(self):
        return f"id: {self.id}, name: {self.job_title}"