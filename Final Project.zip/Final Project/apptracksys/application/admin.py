from django.contrib import admin
from .models import Sample,Jobs
# Register your models here.
admin.site.register(Sample)
admin.site.register(Jobs)